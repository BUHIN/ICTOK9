package com.diary.biz.users.vo;

import java.sql.Date;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Component("userVO")
public class UserVO {
	
	@NotEmpty(message="���̵�please")
	@Pattern(regexp="^[a-zA-Z1-9]+$", message="id�� �ҹ���, ���ڸ�")
	private String userid;
	@NotEmpty(message="���please")
	@Pattern(regexp="^[a-zA-Z1-9]+$", message="pw�� ���� ��,�ҹ���, ���ڸ�")
	@Size(min=6, max=10, message="pw�� 6~10�ڸ�")
	private String password;
	@Size(min=1, max=10, message="���� �̸��� �̷��� ���?")
	private String name;
	private String regdate;
	private String lastclick;
	
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	
	public String getLastclick() {
		return lastclick;
	}
	public void setLastclick(String lastclick) {
		this.lastclick = lastclick;
	}
	@Override
	public String toString() {
		return "Users [userid=" + userid + ", password=" + password + ", name="
				+ name + ", regdate=" + regdate + "]";
	}
	
	
}
