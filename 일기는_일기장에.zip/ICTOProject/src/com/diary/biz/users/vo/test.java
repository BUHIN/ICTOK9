package com.diary.biz.users.vo;

import java.util.Calendar;


public class test {
	public static void main(String[] args) {
		Calendar cal = Calendar.getInstance();
		int year = cal.get(cal.YEAR);
		int month = cal.get(cal.MONTH)+1;
		int date = cal.get(cal.DATE);
		
		String today = year+"-"+month+"-"+date;
		System.out.println(today);

	}

}
