package com.diary.biz.diary.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.diary.biz.diary.vo.DiaryVO;

@Repository("diaryDAO")
public class DiaryDAO {
	
	@Autowired
	private SqlSession sql;
	
	public void addDiary(DiaryVO vo){
		int insert = sql.insert("addDiary", vo);
		System.out.println(insert+"�� ���");
	}
	public List<Object> getDiaryList(DiaryVO vo){ 
		return sql.selectList("getDiaryList", vo);
	}
	public DiaryVO getDiary(DiaryVO vo){
		return sql.selectOne("getDiary", vo);
	}
	public void deleteDiary(DiaryVO vo){
		sql.delete("deleteDiary", vo);
	}
	public void updateDiary(DiaryVO vo){
		sql.update("updateDiary", vo);
	}
	public DiaryVO getSomeonesDiary(DiaryVO vo){
		DiaryVO diary = sql.selectOne("getSomeonesDiary", vo);
		return diary;
	}
}
