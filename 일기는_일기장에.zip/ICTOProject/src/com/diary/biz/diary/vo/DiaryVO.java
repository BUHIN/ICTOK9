package com.diary.biz.diary.vo;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Component("diaryVO")
public class DiaryVO {
	private int seq;
	private String title;
	private String content;
	private String img;
	private String video;
	private double dlat;
	private double dlong;
	private String regdate;
	private String userid;
	private String movie;
	private MultipartFile uploadImg;
	public DiaryVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DiaryVO(int seq, String title, String content, String img,
			String video, double dlat, double dlong, String regdate,
			String userid, String movie) {
		super();
		this.seq = seq;
		this.title = title;
		this.content = content;
		this.img = img;
		this.video = video;
		this.dlat = dlat;
		this.dlong = dlong;
		this.regdate = regdate;
		this.userid = userid;
		this.movie = movie;
	}
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public String getVideo() {
		return video;
	}
	public void setVideo(String video) {
		this.video = video;
	}
	public double getDlat() {
		return dlat;
	}
	public void setDlat(double dlat) {
		this.dlat = dlat;
	}
	public double getDlong() {
		return dlong;
	}
	public void setDlong(double dlong) {
		this.dlong = dlong;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getMovie() {
		return movie;
	}
	public void setMovie(String movie) {
		this.movie = movie;
	}
	
	public MultipartFile getUploadImg() {
		return uploadImg;
	}
	public void setUploadImg(MultipartFile uploadImg) {
		this.uploadImg = uploadImg;
	}
	@Override
	public String toString() {
		return "DiaryVO [seq=" + seq + ", title=" + title + ", content="
				+ content + ", img=" + img + ", video=" + video + ", dlat="
				+ dlat + ", dlong=" + dlong + ", regdate=" + regdate
				+ ", userid=" + userid + ", movie=" + movie + ", uploadImg="
				+ uploadImg + "]";
	}
	
	
	
}
