package com.diary.view.diary;

import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.diary.biz.diary.impl.DiaryDAO;
import com.diary.biz.diary.vo.DiaryVO;
import com.diary.biz.diary.vo.Movie;
import com.diary.biz.users.impl.UserDAO;
import com.diary.biz.users.vo.UserVO;

@Controller
public class DiaryController {
	@Autowired
	private DiaryDAO dao;
	@Autowired
	private UserDAO dao2;
	
	Calendar cal = Calendar.getInstance();
	int year = cal.get(cal.YEAR);
	int month = cal.get(cal.MONTH)+1;
	int date = cal.get(cal.DATE);
	
	String today = year+"-"+month+"-"+date;
	
	@RequestMapping( value = "/addDiary.do")
	public String addDiary(DiaryVO vo, HttpServletRequest request,
			HttpSession session/*,
			MultipartFile image,
			@RequestParam(required = false) MultipartFile video*/)
			throws IllegalStateException, IOException {
		String userid = (String) session.getAttribute("userid");
		if (userid == null) {
			return "login.do";
		}
		if (vo.getContent() == null || vo.getTitle() == null
				|| vo.getDlat() == 0 || vo.getDlong() == 0) {
			vo.setContent("");
			vo.setDlat(0);
			vo.setDlong(0);
			vo.setTitle("");
		}
		MultipartFile uploadImg = vo.getUploadImg();
		if (uploadImg != null && uploadImg.getOriginalFilename().length() > 0) {
			String fileName = uploadImg.getOriginalFilename();
			byte[] fileData = uploadImg.getBytes();
			FileOutputStream output = new FileOutputStream(
					"c:/JavaWorks111/ICTOProject/WebContent/img/" + fileName);
			output.write(fileData);
			output.close();
			vo.setImg("img/" + fileName);
		} else{
			vo.setImg("noImage");
		}
		
		vo.setUserid(userid);
		vo.setVideo("video");
		dao.addDiary(vo);
		return "create.jsp";
	}
	
	@RequestMapping(value = "/selectDiaryList.do")
	public String getDiaryList(DiaryVO vo,String autoAddress, HttpServletRequest request,
			HttpSession session, Model model){
		String userid = (String) session.getAttribute("userid");
		if(userid==null){
			return "login.do";
		}
		vo.setUserid(userid);
		List<Object> list = dao.getDiaryList(vo);
		session.setAttribute("today", today);
		model.addAttribute("list", list);
		return "index.jsp";
	}
	@RequestMapping(value = "/getDiary.do")
	public String getDiary(DiaryVO vo,String autoAddress, HttpServletRequest request,
			HttpSession session, Model model){
		boolean isSecret = false;
		String userid = (String) session.getAttribute("userid");
		if (userid == null) {
			return "login.do";
		}
		vo.setUserid(userid);
		vo.setSeq(vo.getSeq());
		model.addAttribute("diary", dao.getDiary(vo));
		model.addAttribute("isSecret",isSecret);

		return "detail.jsp";
	}
	@RequestMapping(value = "/deleteDiary.do")
	public String deleteDiary(DiaryVO vo,String autoAddress, HttpServletRequest request,
			HttpSession session, Model model){
		String userid = (String) session.getAttribute("userid");
		vo.setUserid(userid);
		vo.setSeq(vo.getSeq());
		dao.deleteDiary(vo);
		return "selectDiaryList.do";
	}
	@RequestMapping(value="/goUpdateDiary.do")
	public String goUpdateDiary(DiaryVO vo, HttpServletRequest request,
			HttpSession session, Model model) throws IOException{
		String userid = (String) session.getAttribute("userid");
		if (userid == null) {
			return "login.do";
		}
		vo.setUserid(userid);
		vo.setSeq(vo.getSeq());
		model.addAttribute("diary", dao.getDiary(vo));
		return "update.jsp";
	}
	@RequestMapping(value="/updateDiary.do")
	public String updateDiary(DiaryVO vo, HttpServletRequest request,
			HttpSession session, Model model) throws IOException{
		String userid = (String) session.getAttribute("userid");
		if (userid == null) {
			return "login.do";
		}
		if (vo.getContent() == null || vo.getTitle() == null
				|| vo.getDlat() == 0 || vo.getDlong() == 0) {
			vo.setContent("");
			vo.setDlat(0);
			vo.setDlong(0);
			vo.setTitle("");
		}
		MultipartFile uploadImg = vo.getUploadImg();
		if (uploadImg != null && uploadImg.getOriginalFilename().length() > 0) {
			String fileName = uploadImg.getOriginalFilename();
			byte[] fileData = uploadImg.getBytes();
			FileOutputStream output = new FileOutputStream(
					"c:/JavaWorks111/ICTOProject/WebContent/img/" + fileName);
			output.write(fileData);
			output.close();
			vo.setImg("img/" + fileName);
		}
		vo.setUserid(userid);
		vo.setSeq(vo.getSeq());
		dao.updateDiary(vo);
		return "selectDiaryList.do";
	}
	@RequestMapping(value = "/movie_parsing.do")
	@ResponseBody
	public ArrayList<Movie> movie_parsing(Model model, String query) {
		ArrayList<Movie> list = null;
		try {
			Document document = DocumentBuilderFactory
					.newInstance()
					.newDocumentBuilder()
					.parse("http://openapi.naver.com/search?key=729f00be0c76b6e100138505086a0884&query="
							+ query + "&display=100&start=1&target=movie");
			XPath xpath = XPathFactory.newInstance().newXPath();
			NodeList ntitle = (NodeList) xpath.evaluate("//item/title",
					document, XPathConstants.NODESET);
			NodeList nlink = (NodeList) xpath.evaluate("//item/link", document,
					XPathConstants.NODESET);
			NodeList nimage = (NodeList) xpath.evaluate("//item/image",
					document, XPathConstants.NODESET);
			NodeList nsubtitle = (NodeList) xpath.evaluate("//item/subtitle",
					document, XPathConstants.NODESET);
			NodeList npubDate = (NodeList) xpath.evaluate("//item/pubDate",
					document, XPathConstants.NODESET);
			NodeList ndirector = (NodeList) xpath.evaluate("//item/director",
					document, XPathConstants.NODESET);
			NodeList nactor = (NodeList) xpath.evaluate("//item/actor",
					document, XPathConstants.NODESET);
			NodeList nuserRating = (NodeList) xpath.evaluate(
					"//item/userRating", document, XPathConstants.NODESET);

			String title, link, image, subtitle, pubDate, director, actor, userRating = "";

			list = new ArrayList<>();

			for (int idx = 0; idx < ntitle.getLength(); idx++) {
				title = ntitle.item(idx).getTextContent().trim();
				link = nlink.item(idx).getTextContent().trim();
				image = nimage.item(idx).getTextContent().trim();
				subtitle = nsubtitle.item(idx).getTextContent().trim();
				pubDate = npubDate.item(idx).getTextContent().trim();
				director = ndirector.item(idx).getTextContent().trim();
				actor = nactor.item(idx).getTextContent().trim();
				userRating = nuserRating.item(idx).getTextContent().trim();
				list.add(new Movie(title, link, image, subtitle, pubDate,
						director, actor, userRating));
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (XPathExpressionException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		}
		return list;
	}

	@RequestMapping(value = "/getSomeonesDiary.do")
	public String getSomeonesDiary(DiaryVO vo, UserVO user, HttpSession session, Model model){
		String userid = (String) session.getAttribute("userid");
		String lastclick = (String) session.getAttribute("lastclick");
		if(userid==null){
			return "login.do";
		}
		
		
		if(lastclick==null){
			lastclick="";
		}
		
		vo.setUserid(userid);
		user.setLastclick(today);
		user.setUserid(userid);
		boolean isSecret = true;
		DiaryVO diary = dao.getSomeonesDiary(vo);
		dao2.updateLastclick(user);
		model.addAttribute("diary",diary);
		model.addAttribute("isSecret",isSecret);
		session.setAttribute("lastclick", today);
		return "detail.jsp";
	}
}
