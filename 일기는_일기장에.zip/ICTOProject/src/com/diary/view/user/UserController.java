package com.diary.view.user;

import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.diary.biz.users.impl.UserDAO;
import com.diary.biz.users.vo.UserVO;

@Controller
public class UserController {

	@Autowired
	private UserDAO dao;
	
	@Autowired
	private Validator validator;
	
	@InitBinder
	public void initBinder(WebDataBinder dataBinder){
		dataBinder.setValidator(this.validator);
	}

	@RequestMapping(method=RequestMethod.GET, value="/login.do")
	public String showLogin(Map<String, UserVO> model){
		UserVO user  = new UserVO();
		model.put("user", user);
		return "login.jsp";
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/login.do")
	public String processLogin(@ModelAttribute("user") @Valid UserVO vo, BindingResult result, Map<String, UserVO> model, HttpSession session){
		UserVO user= dao.login(vo);
		if(!result.hasErrors()){
			if(user!=null){
				session.setAttribute("userid", user.getUserid());
				session.setAttribute("name", user.getName());
				session.setAttribute("lastclick", user.getLastclick());
				return "selectDiaryList.do";
			}
		}
		System.out.println(result.toString());
		return "login.jsp";
	}
	
	@RequestMapping(method=RequestMethod.GET, value="/signup.do")
	public String showSignup(Map<String, UserVO> model){
		UserVO user = new UserVO();
		model.put("user", user);
		return "login.jsp";
	}

	@RequestMapping(method=RequestMethod.POST, value="/signup.do")
	public String processSignup(@ModelAttribute("user") @Valid UserVO vo, BindingResult result, Map<String, UserVO> model){
			dao.signup(vo);
			return "login.jsp";
	}
	
	@RequestMapping(value="/logout.do")
	public String handleRequest(HttpSession session) {
		session.invalidate();
		return "login.do";
	}
}
