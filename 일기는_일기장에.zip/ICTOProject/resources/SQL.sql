CREATE table "USERS" (
    "USERID"     VARCHAR2(4000) NOT NULL,
    "PASSWORD"   VARCHAR2(4000),
    "NAME"       VARCHAR2(4000),
    "REGDATE"    VARCHAR2(4000),
    constraint  "USERS_PK" primary key ("USERID")
)
delete from diary where userid='thoon'
CREATE TABLE  "DIARY" 
   (	"SEQ" NUMBER(3,0) NOT NULL ENABLE, 
	"TITLE" VARCHAR2(4000), 
	"CONTENT" VARCHAR2(4000), 
	"IMG" VARCHAR2(4000), 
	"VIDEO" VARCHAR2(4000), 
	"DLAT" NUMBER(20,15), 
	"DLONG" NUMBER(20,15), 
	"REGDATE" VARCHAR2(4000), 
	"USERID" VARCHAR2(4000), 
	"MOVIE" VARCHAR2(4000), 
	 CONSTRAINT "DIARY_PK" PRIMARY KEY ("SEQ") ENABLE, 
	 CONSTRAINT "DIARY_FK" FOREIGN KEY ("USERID")
	  REFERENCES  "USERS" ("USERID") ENABLE
   )
/

ALTER TABLE "DIARY" ADD CONSTRAINT "DIARY_FK" 
FOREIGN KEY ("USERID")
REFERENCES "USERS" ("USERID")

/
select * from users
select * from diary
update users set password='jisu123' where password='jisu'
delete from DIARY
insert into users values('jisu', 'jisu', 'jisu', sysdate);
insert into diary values((select nvl(max(seq),0)+1 from diary),'aa','bb','cc','dd',38,38,sysdate,'jisu','movie')

alter table users add (lastclick date)


update users set lastclick=sysdate where userid='thoon'

